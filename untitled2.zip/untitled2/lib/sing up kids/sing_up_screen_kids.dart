import 'package:flutter/material.dart';

class singUpkids extends StatelessWidget {

  static String routeName = "/signUpkids";
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Sign Up kids"),
      ),
      body: Body(),
    );
  }
}
